import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Todo } from '../../models/todo';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'todo-container',
  template: `
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <h1 class="title">Todos</h1>

          <ng-container *ngIf="todos">
          <todo-form (addTodo)="addTodo($event)"></todo-form>

          <todo-nav
            [navItems]="navItems"
            [statusNav]="selectedNavItem"
            (changeStatusNav)="setCurrentNavItem($event)"></todo-nav>

          <todo-list
            [todos]="todos"
            [statusNav]="selectedNavItem"
            (removeTodo)="removeTodo($event)"
            (toggleComplete)="toggleComplete($event)"></todo-list>

          <todo-footer
            [cntCompletedTodos]="getCntCompletedTodos()"
            [cntActiveTodos]="getCntActiveTodos()"
            (changeStatusToggleAllTodo)="toggleAllTodoAsComplete($event)"
            (removeCompletedTodos)="removeCompletedTodos()"></todo-footer>

          </ng-container>
          <div class="col-md-12" style="margin-top: 30px">
            <pre>{{todos | json}}</pre>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TodoContainerComponent implements OnInit {
  todos: Todo[];
  // navigation items
  navItems = ['All', 'Active', 'Completed'];
  // 선택된 navigation item
  selectedNavItem: string;
  // ServerURL
  appUrl: string = environment.apiUrl;

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.getTodos();
    this.selectedNavItem = this.navItems[0];
  }

  getTodos() {
    this.http.get<Todo[]>(this.appUrl)
      .subscribe(todos => this.todos = todos);
  }

  addTodo(content: string) {
    const payLoad = { id: this.lastTodoId(), content, completed: false };
    this.http.post(this.appUrl, payLoad)
      .subscribe(() => this.todos = [payLoad, ...this.todos]);
  }

  removeTodo(id: number) {
    this.http.delete(`${this.appUrl}/id/${id}`, {responseType: 'text'})
      .subscribe(() => this.todos = this.todos.filter(todo => todo.id !== id));
  }

  removeCompletedTodos() {
    this.http.delete(`${this.appUrl}/completed`, { responseType: 'text' })
      .subscribe(() => this.todos = this.todos.filter(todo => todo.completed !== true));
  }

  toggleComplete(id: any) {
    // this.todos.forEach(todo => {
    //   todo = todo.id === id ? Object.assign(todo, { completed: !todo.completed }) : todo;
    // });
    const { completed } = this.todos.find(todo => todo.id === id );
    const payLoad = { completed: !completed };
    this.http.patch(`${this.appUrl}/id/${id}`, payLoad, { responseType: 'text' })
      .subscribe(() => this.todos = this.todos.map(todo => {
      return todo.id === id ? Object.assign( todo, payLoad ) : todo;
    }));
  }

  toggleAllTodoAsComplete(completed: boolean) {
    // this.todos.forEach(todo => todo = Object.assign({}, todo, { completed }));
    this.http.patch(`${this.appUrl}`, completed , { responseType: 'text' })
      .subscribe(() => this.todos = this.todos.map(todo => Object.assign(todo, { completed })));
  }

  setCurrentNavItem(selectedNavItem: string) {
    this.selectedNavItem = selectedNavItem;
  }

  getCntCompletedTodos(): number {
    return this.todos.filter(todo => todo.completed).length;
  }

  getCntActiveTodos(): number {
    return this.todos.filter(todo => !todo.completed).length;
  }

  lastTodoId(): number {
    return this.todos.length ? Math.max(...this.todos.map(({ id }) => id)) + 1 : 1;
  }
}
