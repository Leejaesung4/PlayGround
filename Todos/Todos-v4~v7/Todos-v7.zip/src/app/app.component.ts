import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<todo-container></todo-container>'
})
export class AppComponent {}
