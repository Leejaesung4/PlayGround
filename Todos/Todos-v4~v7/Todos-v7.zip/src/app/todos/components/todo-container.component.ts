import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Todo } from '../../models/todo';
import { environment } from '../../../environments/environment';
import { TodoService } from '../todo.service';

@Component({
  selector: 'todo-container',
  template: `
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <h1 class="title">Todos</h1>

          <ng-container *ngIf="todoService.todos">
          <todo-form></todo-form>

          <todo-nav
            [navItems]="navItems"
            [statusNav]="selectedNavItem"
            (changeStatusNav)="selectedNavItem=$event"></todo-nav>

          <todo-list [statusNav]="selectedNavItem"></todo-list>

          <todo-footer></todo-footer>

          </ng-container>
          <div class="col-md-12" style="margin-top: 30px">
            <pre>{{todoService.todos | json}}</pre>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TodoContainerComponent {
  // todos: Todo[];
  // navigation items
  navItems = ['All', 'Active', 'Completed'];
  // 선택된 navigation item
  selectedNavItem: string =  this.navItems[0];
  // ServerURL
  // appUrl: string = environment.apiUrl;

  constructor(public todoService: TodoService) { }

}
