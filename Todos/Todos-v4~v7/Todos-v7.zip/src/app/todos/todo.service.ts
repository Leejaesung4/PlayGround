import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/observable';

import { environment } from '../../environments/environment';
import { Todo } from '../models/todo';

@Injectable()
export class TodoService {
    appUrl = environment.apiUrl;
    todos: Todo[];
    
    constructor(private http: HttpClient) {
    console.log('[appUrl]', this.appUrl);
    this.findAll();
    }
    
    findAll() {
    this.http.get<Todo[]>(this.appUrl)
    .subscribe(todos => this.todos = todos);
    }

    create(content: string) {
    const payLoad = { id: this.lastTodoId(), content, completed: false };
    this.http.post(this.appUrl, payLoad)
        .subscribe(() => this.todos = [payLoad, ...this.todos]);
    }

    removeById(id: number) {
    this.http.delete(`${this.appUrl}/id/${id}`, { responseType: 'text' })
        .subscribe(() => this.todos = this.todos.filter(todo => todo.id !== id));
    }

    removeByCompleted() {
        this.http.delete(`${this.appUrl}/completed`, { responseType: 'text' })
            .subscribe(() => this.todos = this.todos.filter(todo => todo.completed !== true));
    }

    updateByID(id: number) {
    const { completed } = this.todos.find(todo => todo.id === id);
    const payLoad = { completed: !completed };
    this.http.patch(`${this.appUrl}/id/${id}`, payLoad, { responseType: 'text' })
        .subscribe(() => this.todos = this.todos.map(todo => {
            return todo.id === id ? Object.assign(todo, payLoad) : todo;
        }));
    }

    updateAll(completed: boolean) {
    this.http.patch(`${this.appUrl}`, completed, { responseType: 'text' })
        .subscribe(() => this.todos = this.todos.map(todo => Object.assign(todo, { completed })));
    }
        
    private lastTodoId(): number {
        return this.todos.length ? Math.max(...this.todos.map(({ id }) => id)) + 1 : 1;
    }
}

